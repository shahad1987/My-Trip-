package project;
import java.awt.*;
import java.sql.*;
import javax.swing.*;
public class jeddah extends javax.swing.JFrame {
Connection connection = null;
Statement statement = null;
ResultSet resultSet = null;
String query;
public jeddah() {
    initComponents();
    jComboBox1.setBackground(Color.WHITE);
    jComboBox2.setBackground(Color.WHITE);
    jComboBox3.setBackground(Color.WHITE);
    jComboBox4.setBackground(Color.WHITE);
    DoneButton.setBackground(Color.WHITE);
    doConnect();
    String email = " ";
String e = em(email);
try {
                doConnect();
                String query = "select * from Hotel";
                statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                resultSet = statement.executeQuery(query);
                for (int i = 1; i <= 5; i++) {
                    resultSet.next();

                    jComboBox2.addItem(resultSet.getString("Hotel"));
                }

            } catch (SQLException sqlEx) {
                JOptionPane.showMessageDialog(null, sqlEx.getMessage());

            }
try {
                doConnect();
                String query = "select * from place";
                statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                resultSet = statement.executeQuery(query);
                resultSet.absolute(4);

                while (resultSet.next()) {

                    jComboBox3.addItem(resultSet.getString("Place"));
                }

            } catch (SQLException sqlEx) {
                JOptionPane.showMessageDialog(null, sqlEx.getMessage());

            }
try {
                doConnect();
                String query = "select * from tourist_guide";
                statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                resultSet = statement.executeQuery(query);
                for (int i = 1; i <= 4; i++) {
                    resultSet.next();

                    jComboBox4.addItem(resultSet.getString("Guide_name"));
                }

            } catch (SQLException sqlEx) {
                JOptionPane.showMessageDialog(null, sqlEx.getMessage());

            }
}
public void doConnect( ) {
try {
    String URL = "jdbc:mysql://localhost:3306/trips";
    String username = "root";
    String password = "1234";
    query = "select * from trip_info";

    connection = DriverManager.getConnection(URL, username, password);
    statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
    resultSet = statement.executeQuery(query); } 
catch (SQLException ex) {
    JOptionPane.showMessageDialog(this, ex.getMessage());
}}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel(){
            public void paintComponent(Graphics g) {
                ImageIcon img = new ImageIcon(getClass().getResource("background.jpg"));
                Image i=img.getImage();
                g.drawImage(i, 0, 0, this.getSize().width, this.getSize().height, this);}
        }
        ;
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        DoneButton = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        jComboBox4 = new javax.swing.JComboBox();
        jComboBox3 = new javax.swing.JComboBox();
        PriceButton = new javax.swing.JButton();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Jeddah");

        jLabel7.setFont(new java.awt.Font("Serif", 1, 30)); // NOI18N
        jLabel7.setText("Jeddah");

        jLabel8.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        jLabel8.setText("Select Date:");

        DoneButton.setBackground(new java.awt.Color(255, 255, 255));
        DoneButton.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        DoneButton.setText("Done");
        DoneButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DoneButtonActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        jLabel9.setText("Cabin:");

        jLabel10.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        jLabel10.setText("Tourist Guides:");

        jComboBox1.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Economic", "Tourist", "Business", "First Class" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        jLabel11.setText("Tourist Places:");

        jLabel12.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        jLabel12.setText("Hotels:");

        jComboBox2.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jComboBox4.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N

        jComboBox3.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N

        PriceButton.setBackground(new java.awt.Color(255, 255, 255));
        PriceButton.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        PriceButton.setText("Check Price");
        PriceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PriceButtonActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        jLabel1.setText("Email");

        jTextField1.setEditable(false);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(228, 228, 228)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel10)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel11)
                                        .addComponent(jLabel8)
                                        .addComponent(jLabel12)
                                        .addComponent(jLabel9)))
                                .addGap(122, 122, 122)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jComboBox3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jComboBox1, 0, 161, Short.MAX_VALUE)
                                        .addComponent(jComboBox4, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jDateChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(377, 377, 377)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                            .addGap(293, 293, 293)
                            .addComponent(PriceButton)
                            .addGap(18, 18, 18)
                            .addComponent(DoneButton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(257, 257, 257)
                        .addComponent(jLabel1)))
                .addGap(307, 307, 307))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(36, 36, 36)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(38, 38, 38)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(36, 36, 36)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(69, 69, 69)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PriceButton)
                    .addComponent(DoneButton))
                .addGap(104, 104, 104))
        );

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project/menu.png"))); // NOI18N

        jMenuItem1.setMnemonic('H');
        jMenuItem1.setText("Home Page");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setMnemonic('L');
        jMenuItem2.setText("Logout");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setMnemonic('A');
        jMenuItem3.setText("About Us");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        dispose();    
                Frame1 home = new Frame1();
                home.email(jTextField1.getText());
                home.setTitle("Home Page");
                Toolkit kit = Toolkit.getDefaultToolkit();
                home.setLocation(kit.getScreenSize().width /5, kit.getScreenSize().height /8);
                home.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                home.setSize(900,800);
                home.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
    setVisible(false);
    dispose();
    AboutUs c=new AboutUs();
    c.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     c.em(jTextField1.getText());
    Toolkit kit = Toolkit.getDefaultToolkit();
    c.setLocation(kit.getScreenSize().width /5, kit.getScreenSize().height /8);
    c.setTitle("About Us");
    c.setSize(1200,800);
    c.setVisible(true);       
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void DoneButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoneButtonActionPerformed

java.util.Date day = jDateChooser1.getDate();
String cabin = (String) jComboBox1.getItemAt(jComboBox1.getSelectedIndex());
String hotel = (String) jComboBox2.getItemAt(jComboBox2.getSelectedIndex());
String place = (String) jComboBox3.getItemAt(jComboBox3.getSelectedIndex());
String guide = (String) jComboBox4.getItemAt(jComboBox4.getSelectedIndex());
String d= String.valueOf(day);
try {
       String query = "select * from trip_info";
                statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                resultSet = statement.executeQuery(query);
    if(jDateChooser1.getCalendar().equals("") ) {
      throw new Exception();}
    resultSet.moveToInsertRow();  
   // resultSet.updateInt("id", id);
    resultSet.updateString("Email", jTextField1.getText());
    resultSet.updateString("Cabin", cabin);
    resultSet.updateString("Hotel", hotel);
    resultSet.updateString("Guide", guide);
    resultSet.updateString("Place", place);
    resultSet.updateString("Date", d);
    resultSet.updateString("Country", "Jeddah");
    resultSet.insertRow();
    resultSet.close();
    statement.close();

    statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
    resultSet = statement.executeQuery(query);
    resultSet.next();
    JOptionPane.showMessageDialog(null,"Do you want to complete the order? "+jDateChooser1.getDate()+" ,Correct Date?", "", JOptionPane.INFORMATION_MESSAGE);
    setVisible(false);
    dispose();
    payment p= new payment();
    p.email(jTextField1.getText());
    p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    p.setTitle("Payment");
   Toolkit kit = Toolkit.getDefaultToolkit();
                p.setLocation(kit.getScreenSize().width /5, kit.getScreenSize().height /8);
                p.setSize(900, 800);
    p.setVisible(true);} 
catch (SQLException sqlEx){
    JOptionPane.showMessageDialog(this, sqlEx.getMessage());} 
catch (Exception ex) {    
    JOptionPane.showMessageDialog(null,"Please select all required fields to continue", "Error", JOptionPane.INFORMATION_MESSAGE);} 
    }//GEN-LAST:event_DoneButtonActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void PriceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PriceButtonActionPerformed
        double price=0;
        String h=jComboBox2.getSelectedItem().toString();
        String p=jComboBox3.getSelectedItem().toString();
        //price hotel
        if(h.equals("Jeddah Hilton")||h.equals("The Venue Jeddah Corniche"))
        price=price+1150;
        else if(h.equals("The Ritz-Carlton Jeddah"))
        price=price+2000;
        else if(h.equals("Rosewood Jeddah"))
        price=price+950;
        else if(h.equals("The Hotel Galleria By Elaf"))
        price=price+1050;
        //price place
        if(p.equals("Jeddah Country")||p.equals("Historic Jeddah Festival"))
        price=price+100;
        else if(p.equals("Jeddah Corniche"))
        price=price+10;
        else if(p.equals("Fakieh Aquarium"))
        price=price+250;
        JOptionPane.showMessageDialog(null,"Price= "+price, "price", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_PriceButtonActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        dispose();    
                Frame2 logout = new Frame2();
                logout.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                Toolkit kit = Toolkit.getDefaultToolkit();
                logout.setLocation(kit.getScreenSize().width /5, kit.getScreenSize().height /8);
                logout.setTitle("Log Out");
                logout.setSize(700, 600);
                logout.setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed
        
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         *//*
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(jeddah.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(jeddah.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(jeddah.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jeddah.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jeddah().setVisible(true);
            }
        });}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DoneButton;
    private javax.swing.JButton PriceButton;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JComboBox jComboBox3;
    private javax.swing.JComboBox jComboBox4;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel3;
    public javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
public String  em(String e){
    String em =e ;
  jTextField1.setText(em);
  return em;
}
}