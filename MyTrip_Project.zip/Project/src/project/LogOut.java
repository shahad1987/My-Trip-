package project;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class LogOut {
    public static void main(String[] args) {
        Frame2 a = new Frame2();
       Toolkit kit = Toolkit.getDefaultToolkit();
      a.setLocation(kit.getScreenSize().width /5, kit.getScreenSize().height /8);
    a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a.setSize(700, 600);
        a.setVisible(true);
    }

}
class Frame2 extends JFrame {

    Panel1 panel1 = new Panel1();
    Panel2 a = new Panel2(600, 800);
    JButton b1, b2;

    Frame2() {

        setLayout(null);

        a.setBounds(100, 150, 480, 80);
        add(a);

        panel1.setBounds(0, 0, 680, 380);
        add(panel1);

        b1 = new JButton("Exit");

        b1.setBounds(150, 300, 130, 30);
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                dispose();

            }
        });
        b1.setBackground(Color.gray);
        panel1.add(b1);

        b2 = new JButton("Home Page");

        b2.setBackground(Color.gray);
        b2.setBounds(350, 300, 130, 30);
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                dispose();
      Home home = new Home();
      Toolkit kit = Toolkit.getDefaultToolkit();
      home.setLocation(kit.getScreenSize().width /5, kit.getScreenSize().height /8);
      home.setSize(900, 800);
    home.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    home.setVisible(true);
            }
        });
        panel1.add(b2);

        panel1.setBounds(0, 0, 700, 600);
        add(panel1);

    }

    class Panel1 extends JPanel {

        Panel1() {
            setLayout(null);

        }
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            ImageIcon image1 = new ImageIcon(getClass().getResource("end.gif"));
            Image a = image1.getImage();
            g.drawImage(a, 0, 0, this.getSize().width, this.getSize().height, this);
        }
    }
    class Panel2 extends JPanel {
        BufferedImage f;
        String text = "Thank you for visiting our program";
        Font font = new Font("Serif", Font.ITALIC, 50);
        double x, y;
        Panel2(int w, int h) {
            f = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
            x = w;
        }
        public void paintComponent(Graphics g) {
            super.paintComponent(g);

            move(f.getGraphics());
            g.drawImage(f, 0, 0, null);
            x -= 0.05;
            repaint();
        }

        public void move(Graphics g) {
            g.clearRect(0, 0, getWidth(), getHeight());
            g.setFont(font);
            y = getHeight() / 1.75;
            g.drawString(text, (int) x, (int) y);

        }

    }
}
