package project;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
 class Home extends JFrame{
 private pic h ;
  JButton b ;
 public static void main(String[] args) {
    Home home = new Home();
      Toolkit kit = Toolkit.getDefaultToolkit();
      home.setLocation(kit.getScreenSize().width /5, kit.getScreenSize().height /8);
      home.setSize(900, 800);
      home.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      home.setVisible(true);
 }
Home(){
super("Hello to MY Trip Program");
h = new pic();
b = new JButton("HOME");
Font font = new Font("Serif", Font.BOLD, 15);
b.setFont(font);
b.setForeground(Color.white);
b.setBackground(Color.lightGray);
h.setBounds(0, 0, 900, 800);
b.setBounds(350, 680, 200, 50);
h.add(b);
add(h);
 Handler h = new Handler();
 b.addActionListener(h);
    }

private class Handler implements ActionListener {
        @Override
public void actionPerformed(ActionEvent e) {
  dispose();
  SignIn log = new SignIn();
  log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  log.pack();
  log.setLocationRelativeTo(null);
  Toolkit kit = Toolkit.getDefaultToolkit();
  log.setLocation(kit.getScreenSize().width /5, kit.getScreenSize().height /8);
  log.setSize(900, 800);
  log.setVisible(true);
        }
    }
class pic extends JPanel {
  private float A = 1f;
  private float B = -0.02f;
 private BufferedImage img;
 
public pic() {
setLayout(null);
try {
    img = ImageIO.read(new File("C:\\Users\\User\\Desktop\\f.jpg"));
    Timer timer = new Timer(40, new ActionListener() {
public void actionPerformed(ActionEvent e) {
    A = A+ B;
  if (A < 0) {
    B = B*-1;
     A = B;
  } else if (A > 1f) {
   B = B * -1;
    A = 1f + B;
      }
  repaint();
         }
      });
timer.setRepeats(true);
timer.setCoalesce(true);
timer.start();
    } catch (IOException ex) {
          ex.printStackTrace();
            }
        }
@Override
protected void paintComponent(Graphics g) {
 super.paintComponent(g);    
 if (img != null) {
  Graphics2D g2d = (Graphics2D) g.create();
  g2d.setComposite(AlphaComposite.SrcOver.derive(A));
   int x = getWidth() - img.getWidth();
   int y = getHeight() - img.getHeight();
  g2d.drawImage(img, x, y, null);
  g2d.dispose();
            }
        }
    }
}
