package project;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
public class Project {
static final String URL = "jdbc:mysql://localhost/trips";
    static final String username = "root";
    static final String password = "1234";
    static final String query = "select * from trip_info";
    public static void main(String[] args) {
       Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try{
            connection = DriverManager.getConnection(URL, username, password);
            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            ResultSetMetaData  metaData = resultSet.getMetaData();
            int numberOfColumns = metaData.getColumnCount();

            for (int i=1; i<=numberOfColumns; i++)
                System.out.printf("%-20s", metaData.getColumnName(i));
            System.out.println();
            
            while (resultSet.next())
            {
                for (int i=1; i<=numberOfColumns; i++)
                    System.out.printf("%-20s", resultSet.getObject(i));
                System.out.println();
                
            }
        }
catch (SQLException sqlEx) 
        {
            sqlEx.printStackTrace();
        }
        finally
        {
            try
            {
                resultSet.close();
                statement.close();
                connection.close();
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }
        }
    } 
}   

